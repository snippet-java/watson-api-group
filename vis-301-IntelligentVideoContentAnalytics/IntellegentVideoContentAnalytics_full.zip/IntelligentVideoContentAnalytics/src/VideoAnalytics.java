/*
 * import of Java classes
 */
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.*;
/*
 * import of needed opencv classes
 */
import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.core.Size;
import org.opencv.imgcodecs.Imgcodecs;
import org.opencv.imgproc.Imgproc;
import org.opencv.videoio.VideoCapture;

/*
 * import of visual recognition classes
 */
import com.ibm.watson.developer_cloud.visual_recognition.v3.*;
import com.ibm.watson.developer_cloud.visual_recognition.v3.model.*;


 /*
  * Class to analyze video content using classify and detectFaces function of visual recognition service
  */
public class VideoAnalytics {
	/*
	 * window : Main Jframe
	 * Label_on : to display text on top of window
	 * label_left : to display video 
	 * label_underleft : to display text on bottom
	 * textarea_wright : to display objects or faces description
	 * panel_left : in which we make Label_on,label_left and label_underleft
	 * panel : contains all above components
	 */
	JFrame window ;
	JLabel label_on;
    JLabel label_left ;
    JLabel label_underleft;
    JTextArea textarea_wright ;    
    JPanel panel_left;
    JPanel panel;
    
    JScrollPane bar;
    
    /*
     * Necessary instruction to use opencv 
     */
    static {
        System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
    }
    
    /*
     * Constructor that create the Graphic interface
     */
     public VideoAnalytics(){
    	 
    	window = new JFrame("Intelligent video content analytics");
      	window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       
        label_left = new JLabel();
        label_underleft=new JLabel("IBM Watson Visual Recognition service", JLabel.CENTER);
        label_underleft.setFont(new Font("Serif", Font.PLAIN, 30));
        
        label_on=new JLabel("IBM Watson Video Analytics", JLabel.CENTER);
        label_on.setFont(new Font("Serif", Font.PLAIN, 30));
        
        textarea_wright = new JTextArea("");
        
        label_left.setSize(640,480);
        label_underleft.setSize(640,160);
        textarea_wright.setSize(640,640);
        
        panel_left=new JPanel(new BorderLayout());
        panel_left.add(label_underleft,BorderLayout.NORTH);
        panel_left.add(label_left,BorderLayout.CENTER);
        panel_left.add(label_on,BorderLayout.SOUTH);
        
        JScrollPane bar = new JScrollPane (textarea_wright);
        bar.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        
        panel = new JPanel( new GridLayout(1,2) );
        panel.add( panel_left);
       	panel.add(bar);
        
       	window.setContentPane(panel);
        window.setSize(1280, 640);
        window.setVisible(true);   
    }
     
    /*
     * display : function display the video's frames and its text description (objects or faces detected)
     * @frame a BufferedImage to display
     * @str a String object:  text description of objects or faces detected
     */
     public void display(BufferedImage frame, String str){
    	
        ImageIcon imageicon = new ImageIcon(frame);
        label_left.setIcon(imageicon);
        label_left.repaint();
        
        textarea_wright.setText(str);
        textarea_wright.repaint();
        window.setVisible(true);

     }

     /*
      * main function 
      */
	
     public static void main(String[] args) {
    	/*
    	 * 1-Instantiation of visual recognition service
    	 */
    	 VisualRecognition service = new VisualRecognition(VisualRecognition.VERSION_DATE_2016_05_20);
    	 service.setEndPoint("https://gateway-a.watsonplatform.net/visual-recognition/api");
    	 service.setApiKey("57dee0529bc9ec013b1412401114e3d7c72f4caf");
    	 
	    /*
	     * just initiation of variable image as a File, and fruitbowl.jpg not will be used
	     * you can make any image
	     */
    	 File image = new File("fruitbowl.jpg");
    	 
    	 /*
    	  * 2- Load video file ibmvideo.mp4 using VideoCapture 
    	  */
    	  VideoCapture video = new VideoCapture("ibmvideo.mp4");
    	  
    	  // frame a Mat variable to push the frames get from video
    	  Mat frame = new Mat();
    	  
    	  // index : index of image in video
    	  int Index = 0;
    	  
    	  // frequency : a number of frame per second in video
    	  int frequency=40;
    	  
    	  // image to display 
    	  BufferedImage imagetodisplay=null;
    	  
    	  //Create graphic interface by instantiate VideoAnalytics class
    	  VideoAnalytics VFrame=new VideoAnalytics();
    	  
    	  // str : video's frame description
    	  String str= new String();
    	  
    	  // resize image to be displayed
    	  Size size = new Size(640, 480);
    	  
    	  //3-Read looply frame one by one from video, 
    	  while (true) {
    		  
    		  // Check if frame is no empty and we analyzing just one frame from frequency of frames due to redundancy
    		  //of information in video
    		  if (video.read(frame)&&(Index % frequency == 0)) {
    			  Imgproc.resize(frame, frame, size);
        		
    			  //new ClassifyImagesOptions.Builder().images(image) function accept image File as argument
    			  // for that we have created image as File to be passed to images function
           		  Imgcodecs.imwrite("image.jpg", frame);
           		  image=new File("image.jpg");
           		 
           		  try {
           			imagetodisplay=ImageIO.read(image);
           		  }catch (IOException exp) {exp.getMessage();}
           		  
           		  //4- To classify objects we using two instructions below  
           		  /*ClassifyImagesOptions options = new ClassifyImagesOptions.Builder().images(image).build();
        	      VisualClassification result = service.classify(options).execute();
        	      */
           		  
           		
           		  //4- To detect faces we using both instructions below instead the two above
           	      VisualRecognitionOptions detectFaces = new VisualRecognitionOptions.Builder().images(image).build();
        	      DetectedFaces result = service.detectFaces(detectFaces).execute();
        	 
        	      
        	      //Convert result to string 
        	      str=result.toString();
        	 }//end of if
        	 Index++;
        	 
        	 // 5- Display video and result (VisualClassification or DetectedFaces json object) as a string
        	 VFrame.display(imagetodisplay, str);
	    }// end of while

	}//end of main
	
}//end of class